DROP TABLE IF EXISTS `MapwithPay`;
CREATE TABLE `MapwithPay` (
    `OBJECTID` int(25) DEFAULT NULL,
    `CTYUA20CD` varchar(255) DEFAULT NULL,
    `CTYUA20NM` varchar(255) DEFAULT NULL,
    `BNG_E` int(25) DEFAULT NULL,
    `BNG_N` int(25) DEFAULT NULL,
    `LONG` double(10,5) DEFAULT NULL,
    `LAT` double(10,5) DEFAULT NULL,
    `descriptio` varchar(255) DEFAULT NULL,
    `code` varchar(255) DEFAULT NULL,
    `num_of_job` int(25) DEFAULT NULL,
    `median_pay` int(25) DEFAULT NULL,
    `median_ann` double(10,1) DEFAULT NULL,
    `mean_pay` int(25) DEFAULT NULL,
    `mean_annua` double(10,1) DEFAULT NULL,
    `num_of_j_1` int(25) DEFAULT NULL,
    `median_m` int(25) DEFAULT NULL,
    `median_a_1` double(10,1) DEFAULT NULL,
    `mean_m` int(25) DEFAULT NULL,
    `mean_ann_1` double(10,1) DEFAULT NULL,
    `num_of_j_2` int(25) DEFAULT NULL,
    `median_f` int(25) DEFAULT NULL,
    `median_a_2` double(10,1) DEFAULT NULL,
    `mean_f` int(25) DEFAULT NULL,
    `mean_ann_2` double(10,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE 'C:/Users/lenovo/Desktop/SDC assessment/Shapefile/AnnualWhole.csv' 
INTO TABLE MapwithPay
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
SELECT * FROM ucfnuai.MapwithPay; 