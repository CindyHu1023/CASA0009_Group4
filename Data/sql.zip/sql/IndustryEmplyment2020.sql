DROP TABLE IF EXISTS `IndustryEmplyment2020`;
CREATE TABLE `IndustryEmplyment2020` (
    `Period` date DEFAULT NULL,
    `All in employment` int(25) DEFAULT NULL,
    `Public sector` int(25) DEFAULT NULL,
    `Private sector` int(25) DEFAULT NULL,
    `Agriculture, forestry & fishing` int(25) DEFAULT NULL,
    `Mining, energy and water supply` int(25) DEFAULT NULL,
    `Manufacturing` int(25) DEFAULT NULL,
    `Construction` int(25) DEFAULT NULL,
    `Wholesale, retail & repair of motor vehicles` int(25) DEFAULT NULL,
    `Transport & storage` int(25) DEFAULT NULL,
    `Accommod-ation & food services` int(25) DEFAULT NULL,
    `Information & communication` int(25) DEFAULT NULL,
    `Financial & insurance activities` int(25) DEFAULT NULL,
    `Real estate activities` int(25) DEFAULT NULL,
    `Professional, scientific & technical activities` int(25) DEFAULT NULL,
    `Administrative & support services` int(25) DEFAULT NULL,
    `Public admin & defence; social security` int(25) DEFAULT NULL,
    `Education` int(25) DEFAULT NULL,
    `Human health & social work activities` int(25) DEFAULT NULL,
    `Other services` int(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE 'C:/Users/lenovo/Desktop/SDC assessment/emplyment by industry/IndustryEmplyment2020.csv' 
INTO TABLE IndustryEmplyment2020 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
SELECT * FROM ucfnuai.IndustryEmplyment2020;