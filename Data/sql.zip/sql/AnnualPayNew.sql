DROP TABLE IF EXISTS `AnnualPayNew`;
CREATE TABLE `AnnualPayNew` (
    `description` varchar(255) DEFAULT NULL,
    `code` varchar(255) DEFAULT NULL,
    `num_of_jobs(k)` int(25) DEFAULT NULL,
    `median_pay` int(25) DEFAULT NULL,
    `median_annual_change` double(10,1) DEFAULT NULL,
    `mean_pay` int(25) DEFAULT NULL,
    `mean_annual_change` double(10,1) DEFAULT NULL,
    `num_of_jobs_m(k)` int(25) DEFAULT NULL,
    `median_m` int(25) DEFAULT NULL,
    `median_annual_change_m` double(10,1) DEFAULT NULL,
    `mean_m` int(25) DEFAULT NULL,
    `mean_annual_change_m` double(10,1) DEFAULT NULL,
    `num_of_jobs_f(k)` int(25) DEFAULT NULL,
    `median_f` int(25) DEFAULT NULL,
    `median_annual_change_f` double(10,1) DEFAULT NULL,
    `mean_f` int(25) DEFAULT NULL,
    `mean_annual_change_f` double(10,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE 'C:/Users/lenovo/Desktop/SDC assessment/AnnualPay2020.csv' 
INTO TABLE AnnualPayNew
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
SELECT * FROM ucfnuai.AnnualPayNew; 